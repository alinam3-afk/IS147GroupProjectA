import java.util.Date;


public class CheckingAccount extends Account {

    private static final double OVERDRAFT_LIMIT = -100.0;

    public CheckingAccount(int accountNumber, String ownerName,
                           double balance, Date openedOn) {
        super(accountNumber, ownerName, balance, openedOn);
    }

    @Override
    public boolean withdraw(double amount) {
        if (amount <= 0) {
            return false;
        }

        double newBalance = getBalance() - amount;
        newBalance = Math.round(newBalance * 100.0) / 100.0;

        if (newBalance >= OVERDRAFT_LIMIT) {
            setBalance(newBalance);
            return true;
        } else {
            return false;
        }
    }

    public void deposit(double amount, String note) {
        this.deposit(amount);
        System.out.println("Deposit note: " + note.toUpperCase());
    }
}
