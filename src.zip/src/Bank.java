import java.util.Date;
import java.util.Random;


public class Bank {

    private String name;
    private Account[] accounts;
    private int accountCount;

    private static final int MAX_ACCOUNTS = 100;
    private static int numberOfBanks = 0;

    public Bank(String name) {
        this.name = name;
        this.accounts = new Account[MAX_ACCOUNTS];
        this.accountCount = 0;
        numberOfBanks++;
    }

    public static int getNumberOfBanks() {
        return numberOfBanks;
    }

    public Account openCheckingAccount(String ownerName, double initialDeposit) {
        if (accountCount >= MAX_ACCOUNTS) {
            System.out.println("Bank is full. Cannot open more accounts.");
            return null;
        }

        int newNumber = generateAccountNumber();
        Date today = new Date();

        Account newAcc = new CheckingAccount(newNumber, ownerName, initialDeposit, today);
        accounts[accountCount] = newAcc;
        accountCount++;

        System.out.println("Created new checking account #" + newNumber + " for " + ownerName);
        return newAcc;
    }

    public Account findAccount(int accountNumber) {
        for (int i = 0; i < accountCount; i++) {
            if (accounts[i].getAccountNumber() == accountNumber) {
                return accounts[i];
            }
        }
        return null;
    }

    public Account findAccount(String ownerName) {
        for (int i = 0; i < accountCount; i++) {
            if (accounts[i].getOwnerName().equalsIgnoreCase(ownerName.trim())) {
                return accounts[i];
            }
        }
        return null;
    }

    private int generateAccountNumber() {
        Random rand = new Random();
        int base = 100000;
        int number = base + rand.nextInt(900000);
        return number;
    }
}
